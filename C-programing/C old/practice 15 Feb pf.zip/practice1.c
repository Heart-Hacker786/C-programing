#include<stdio.h>
int main()
{
printf("Hi! I am Abdul Wahab");
printf("\nAdress:house#141 street 5 Block D");
printf("\nCity Lahore");
return 0;
}
