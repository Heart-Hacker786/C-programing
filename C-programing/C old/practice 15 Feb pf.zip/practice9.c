#include<stdio.h>
int main()
{
printf("1*");
printf("\n2**");
printf("\n3***");
printf("\n4****");
printf("\n5*****");
return 0;
}
