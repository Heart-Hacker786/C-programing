#include<stdio.h>
#define A "its like a message hehehehe!\n"
int main()
{
printf(A);
printf(A);
return 0;
}
