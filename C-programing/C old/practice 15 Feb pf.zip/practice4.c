#include<stdio.h>
int main()
{
printf(" _______			_______");
printf("\n|_______| >>-----------------> |_______|");
return 0;
}
