#include<stdio.h>
#define name "Abdul Wahab\n"
#define Address "House #141 Block D Pak Arab,Lahore\n"
int main()
{
printf(name);
printf(Address);
printf("Programing is fun.\n");
printf("I like programing.\n");
printf("Programing needs practice and I am ready to do practice.\n");
printf(name);
printf(Address);
return 0;
}
