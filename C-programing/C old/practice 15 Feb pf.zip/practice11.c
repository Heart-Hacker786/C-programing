#include<stdio.h>
int main()
{
printf("-----------------\n");
printf("| W E L C O M E |\n");
printf("-----------------\n");
return 0;
}
