#include<stdio.h>
int main()
{
printf("2 x 1 = 2\n");
printf("2 x 2 = 4\n");
printf("2 x 3 = 6\n");
printf("2 x 4 = 8\n");
printf("2 x 5 = 10\n");
printf("2 x 6 = 12\n");
printf("2 x 7 = 14\n");
printf("2 x 8 = 16\n");
printf("2 x 9 = 18\n");
printf("2 x 10 = 20\n");
return 0;
}
