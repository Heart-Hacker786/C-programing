/*Nth Highest Number*/
/*
Read N, read N elements. Read n & find the nth highest number from list of numbers. For example, in this list of 10 numbers: 32, 14, 26, 8, 10, 11, 13, 15, 17, 19 3rd highest is 19. There are three lines of input. First line has N (number of elements in array). Second line has array elements and third line has n (Positive number less than 100)

input:

10

32 14 26 8 10 11 13 15 17 19

3

Output:

3rd highest number is: 10

Select st, nd, 5d & th carefully.

Input Format

10

2 4 6 8 10 11 13 15 17 19

6

Constraints

0

0

Output Format

6th highest number is: 10
*/
#include <stdio.h>
    int main ()
    {
        int i, j,n,state,temp;
        
        
        scanf("%d", &n);
        int a[n];
        for (i = 0; i < n; ++i){
            scanf("%d", &a[i]);
        }
       for(j=1;j<=150;j++){//Anger caught me 150 times for no reason
    for(i=0;i<n-1;i++){//size index
    if(a[i]>a[i+1]){
    temp=a[i];
    a[i]=a[i+1];
    a[i+1]=temp;
}}}
        scanf ("%d",&state);
        int c=state%10;
        if (c==1)
        printf("%dst highest number is: %d",state,a[n-state]);         
        else if (c==2)
        printf("%dnd highest number is: %d",state,a[n-state]);
        else if (c==3)
        printf("%drd highest number is: %d",state,a[n-state]);
        else
        printf("%dth highest number is: %d",state,a[n-state]);
    return 0;
    }