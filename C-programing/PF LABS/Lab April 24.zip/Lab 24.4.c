/*Averages of Average*/
/*You have score of 3 players in 5 matches. Find average of each player. Find average score in each match. Finally, find overall average. Consider example of two players in three matches. Note order of inputis, scores of first player in all matches, followed by scores of second player in all matches and so on.

30 40 50 40 50 60

Scores of first player is: 30 40 50 with average 40

Scores of second player is: 40 50 60 with average 50

Overall average: 45

Average in first match is: (30+40)/2=35

Average in second match is: (40+50)/2=45

Input Format

30 40 50 60 70 40 50 60 70 80 50 60 70 80 90

Constraints

No Constraint

Output Format

Average of first player is: 50

Average of second player is: 60

Average of third player is: 70

Overall average is: 60

Average in first match is: 40

Average in second match is: 50

Average in third match is: 60

Average in fourth match is: 70

Average in fifth match is: 80*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

   int p1[5],p2[5],p3[5],i,s1=0,s2=0,s3=0;
    for(i=0;i<5;i++){
        scanf("%d",&p1[i]);
    }
    for(i=0;i<5;i++){
        scanf("%d",&p2[i]);
    }
    for(i=0;i<5;i++){
        scanf("%d",&p3[i]);
    }
    for(i=0;i<5;i++){
        s1=s1+p1[i];
        s2=s2+p2[i];
        s3=s3+p3[i];
    }
    printf("Average of first player is: %d\n",s1/5);
    printf("Average of second player is: %d\n",s2/5);
    printf("Average of third player is: %d\n",s3/5);
    printf("Overall average is: %d\n",(s1+s2+s3)/15);
    printf("Average in first match is: %d\n",(p1[0]+p2[0]+p3[0])/3);
    printf("Average in second match is: %d\n",(p1[1]+p2[1]+p3[1])/3);
    printf("Average in third match is: %d\n",(p1[2]+p2[2]+p3[2])/3);
    printf("Average in fourth match is: %d\n",(p1[3]+p2[3]+p3[3])/3);
    printf("Average in fifth match is: %d",(p1[4]+p2[4]+p3[4])/3);

    return 0;
}
