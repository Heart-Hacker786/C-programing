/*Unique Numbers Average*/
/*Find average of unique numbers only. Input 10 postive integers in an array. Find the avarge of elements of array. If an element occurs more then once you just take first time that element for input and ignore for the rest. Consider the example:

10 23 43 12 10 43 89 23 12 3

10+23+43+12+89+3 = 180

180/6 = 30

Calculate average in integer not in float

Input Format

10 23 43 12 10 43 89 23 12 89

Constraints

All number should be positive integres.

Output Format

35*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a[10],i,j,sum=0,count=0,state=0;
    for(i=0;i<10;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<10;i++){
        for(j=0;j<i;j++){
            if(a[i]==a[j])
                state=1;
        }
        if(state!=1){
            count++;
            sum=sum+a[i];
        }
        state=0;
        }
        printf("%d",sum/count);
    return 0;
}
