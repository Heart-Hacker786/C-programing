/*Combine in Order*/
/*Combine elements of two ordered lists in order. There are two lists, of different size, where their combined size is less than 100. You have to combine them in sorted order. Your task is to print them in sorted order, you may use a third array or do the task without using third array. Consider, first list has elements [34 45 57 68 79 84 235 345] and second list has elements [25 98 2359], the required output will be:

25 34 45 57 68 79 84 98 235 345 2359

Input Format

8

34 45 57 68 79 84 235 345

3

25 98 2359

Constraints

Combined count of elements of both lists is less than equal to 100

Output Format

25 34 45 57 68 79 84 98 235 345 2359*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
void pa(int a[],int n);
int main() {

    int a[100],i,j,n,v,temp,count;
    
    scanf("%d",&n);
    int b[n];
    
    for(i=0;i<n;i++){
        scanf("%d",&b[i]);
    }
    scanf("%d",&v);
    int c[v];
    
    for(i=0;i<v;i++){
        scanf("%d",&c[i]);
    }
    for(j=0;j<n;j++){
        a[j]=b[j];
    }
    for(j=0;j<v;j++){
        a[j+n]=c[j];
    }
    for(j=1;j<=150;j++){//index
    for(i=0;i<n+v-1;i++){//size index
    if(a[i]>a[i+1]){
    temp=a[i];
    a[i]=a[i+1];
    a[i+1]=temp;
}}}

    pa(a,n+v);
    return 0;
}
void pa(int a[],int n){
    int j; 
    for(j=0;j<n;j++){
        printf("%d ",a[j]);
    }
    
    
}
