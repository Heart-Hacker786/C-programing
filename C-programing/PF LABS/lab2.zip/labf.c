#include<stdio.h>
int main()
{
int a,b,c,d,e,f,g,h,i,j,k,l;
a=10;
b=20;
c=30;
d= a*a*a;
e= b*b*b;
f= c*c*c;
g=a*a;
h=b*b;
i=c*c;
j=d+h;
k= c * 10;
l=g+h;
printf("%d\t%d\t%d \n", a,b,c);
printf("%d\t%d\t%d \n", g,h,i);
printf("%d\t%d\t%d \n", d,e,f);
printf("%d\n", j);
printf("%d\n", k);
printf("%d\n", l);
return 0;
}
