#include<stdio.h>
int main()
{

printf(" ____	    ___   ___    \n");
printf("|    |	|      |     |  |  |\n");
printf("|    |	|   ___|  ___|  |__| \n");
printf("|    |	|  |         |     |\n");
printf("|____|	|  |___   ___|     |\n");
return 0;
}
