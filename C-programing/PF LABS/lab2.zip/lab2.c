#include<stdio.h>
int main()
{

printf("PUCIT New Campus\n");
printf("Second Semester\n");
printf("Programing Fundamentals\n");
return 0;
}
