#include<stdio.h>
int main()
{
printf("Between \\the lines\\ \n");
printf("I like \'programing\',by others\n");
printf("\\0 is Null characters \n");
return 0;
}
