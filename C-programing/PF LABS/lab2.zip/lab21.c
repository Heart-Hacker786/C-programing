#include<stdio.h>
int main()
{

printf("\"First\" Programing Course\n");
printf("\\n \\t \\b ... are escape sequences\n");
return 0;
}
