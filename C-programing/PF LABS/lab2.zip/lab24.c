#include<stdio.h>
int main()
{
int a,b,c;
a=10;
b=20;
c=30;
printf("%d\n",a);
printf("%d\n",b);
printf("%d\n",c);
return 0;
}
