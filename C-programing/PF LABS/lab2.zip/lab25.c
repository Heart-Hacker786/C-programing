#include<stdio.h>
int main()
{
int a,b,c,d;
a=10;
b=20;
c=30;
d = a*a + b*b + c*c;
printf("%d\n",d);
return 0;
}
