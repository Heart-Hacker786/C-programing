#include<stdio.h>
int main()
{
int a,b,c,d,e,f;
a=10;
b=20;
c=30;
d= a*a*a;
e= b*b*b;
f= c*c*c;
printf("%d\n",d);
printf("%d\n",e);
printf("%d\n",f);
return 0;
}
