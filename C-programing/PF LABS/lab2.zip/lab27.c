#include<stdio.h>
int main()
{
int a,b,c,d,e,f,g;
a=10;
b=20;
c=30;
d= a*a;
e= b*b;
f= c*c*c;
g= e-d; 
printf("B2 - a2 = %d\n",g);
return 0;
}
