/*
Write a function that find the missing element from the unsorted array. First your function have to sort the array in ascending order.You should input the array from user.

Input Format

1 2 5 3

Constraints

Input array should be unsorted Array should be of 10 elements

Output Format

Sorted array:

1 2 3 5

Missing Element:

4

*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int x=0,a[10],i,temp,n;
    for(i=0;i<10;i++){
        scanf("%d",&a[i]);
    }
    for(n=0;n<=10;n++)
    {for(i=0;i<9;i++){
        if(a[i]>a[i+1])
        {temp=a[i+1];
        a[i+1]=a[i];
        a[i]=temp;}
        }}
    printf("Sorted array:\n");
    for(i=0;i<10;i++){
        printf("%d ",a[i]);
        }

    printf("\nMissing Element:\n");
    for(i=a[0];i<=a[9];i++){
        for(n=0;n<10;n++){
        x=0;
            if(i==a[n])
        {
            x=-1;
            break;
        }}
        if(x!=-1)
            printf("%d ",i); 
}
    return 0;
}

