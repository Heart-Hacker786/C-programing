/*Input 10 integers in array. Find the index i such that sum of its previous index and next index value is equal to that index value, and print them. For boundary elements consider array is circular. By circular it means that one has to consider first element to be in between last and second element, similarly last elements is in between second last and first element.

If there is no middle king simply display No King

Input Format

1 -5 -6 4 5 1 7 8 5 6

Constraints

Array has exactly 10 integers.

Output Format

0 1 4 9

*/


#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a[10],i,x=0;
    for(i=0;i<10;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<10;i++){
        if(i==0)
        {if(a[0]==a[1]+a[9])
        {printf("%d ",i);
         x=1;}
        }
        if(i==9)
        {if(a[9]==a[0]+a[8])
        {printf("%d ",i);
            x=1;}
        }
        else{
            if(a[i]==a[i+1]+a[i-1])
            {printf("%d ",i);
                x=1;}
        }}
    if(x==0)
        printf("No King");
    return 0;
}

