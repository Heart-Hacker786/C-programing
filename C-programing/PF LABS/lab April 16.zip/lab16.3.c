/*Create an array of integers.Take different inputs from user and store them in array. Now check whether the contents of array are pallindrome or not. A pallindrome is that which is same after reverse.After checking print the message if input is pallindrome "Input is a pallindrome" else "Input is not a pallindrome".

Input Format

2 3 4 5 6 4 3 2

Constraints

Array has exactly 10 elements. Do not create more than one array, otherwise your answer will not be accepted.

Output Format

Input is a not pallindrome*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a[10],i,n=0;
    for(i=0;i<10;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<5;i++){
        if(a[i]==a[9-i])
        {n++;}}
    if(n==5)
        printf("Input is a pallindrome");
    else
        printf("Input is not a pallindrome");
    return 0;
}
s
