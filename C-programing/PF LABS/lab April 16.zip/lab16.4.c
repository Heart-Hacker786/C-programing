/*Write a program in which you will take array of 10 integers from user and an integer n. Reverses the first n elements of the array for example : A[10]= {1, 3, 5, 7, 9, 8, 12, 6, 24, 2} and n=4 so the output_array will be A[10]= {7, 5, 3, 1, 9, 8, 12, 6, 24, 2}

Input Format

1 2 3 4 5 6 7 8 9 10 10

Constraints

n<=10 Array_size=10

Output Format

10 9 8 7 6 5 4 3 2 1

Sample Input 0

1 2 3 4 5 6 7 8 9 10
10
Sample Output 0

10 9 8 7 6 5 4 3 2 1
Explanation 0

Consider this your example*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a[10],i,temp,n;
    for(i=0;i<10;i++){
        scanf("%d",&a[i]);
    }
    scanf("%d",&n);
    for(i=0;i<n/2;i++)
    {
        temp=a[n-1-i];
        a[n-1-i]=a[i];
        a[i]=temp;
        }
    for(i=0;i<10;i++){
        printf("%d ",a[i]);
        }

    return 0;
}

